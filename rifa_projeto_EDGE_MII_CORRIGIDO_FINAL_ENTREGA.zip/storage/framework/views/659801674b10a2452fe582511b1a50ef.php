<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Rifas</h2>
    <a href="<?php echo e(route('admin.rifas.create')); ?>" class="btn btn-primary mb-3">Nova Rifa</a>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Título</th>
                <th>Descrição</th>
                <th>Valor</th>
                <th>Quantidade</th>
                <th>Sorteio</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $rifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($rifa->titulo); ?></td>
                <td><?php echo e(Str::limit($rifa->descricao, 30)); ?></td>
                <td>R$ <?php echo e(number_format($rifa->valor, 2, ',', '.')); ?></td>
                <td><?php echo e($rifa->quantidade_numeros); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($rifa->data_sorteio)->format('d/m/Y')); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.rifas.edit', $rifa)); ?>" class="btn btn-sm btn-warning">Editar</a>
                    <a href="<?php echo e(route('admin.rifas.compras', $rifa)); ?>" class="btn btn-sm btn-info">Compras</a>
                    <form action="<?php echo e(route('admin.rifas.destroy', $rifa)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Deseja realmente excluir?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger">Excluir</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/htdocs/Sites/rifas/resources/views/admin/rifas/index.blade.php ENDPATH**/ ?>