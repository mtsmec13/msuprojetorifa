<?php $__env->startSection('title', 'Sorteios de Sucesso!'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

    
    <div class="row align-items-center my-5">
        <div class="col-md-7 col-12">
            <div class="esperanca-banner mb-4 mb-md-0">
                <h1 class="mb-2" style="font-size:2rem; font-weight:700;">Mude sua sorte, conquiste prêmios!</h1>
                <p class="mb-3" style="font-size:1.04rem; font-weight:400;">
                    Escolha seu sorteio favorito, pague online, acompanhe o sorteio e veja os ganhadores ao vivo! Sorteios rápidos, transparentes e com prêmios imperdíveis.
                </p>
                <a href="<?php echo e(route('public.rifas.index')); ?>" class="btn btn-main px-4 py-2 mt-1" style="font-size:1.04rem;">Ver Sorteios</a>
            </div>
        </div>
        <div class="col-md-5 col-12 text-center mt-3 mt-md-0">
            <?php if(isset($banners) && $banners->count() && $banners->first()->imagem): ?>
                <img src="<?php echo e($banners->first()->imagem); ?>" class="img-fluid rounded shadow-lg" style="max-height:180px;object-fit:cover;">
            <?php else: ?>
                <img src="https://cdn.pixabay.com/photo/2017/07/04/19/49/lottery-2478477_1280.png" alt="Banner" class="img-fluid" style="max-height:180px;">
            <?php endif; ?>
        </div>
    </div>

    <h2 class="section-title text-center my-4" style="font-size:1.35rem;">Nossos Sorteios</h2>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $rifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-4 col-12 mb-4">
                <div class="card card-premium h-100">
                    <?php if($rifa->imagem): ?>
                        <img src="<?php echo e($rifa->imagem); ?>" class="card-img-top" style="height:110px; object-fit:cover;">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title" style="font-size:1.03rem;"><?php echo e($rifa->titulo); ?></h5>
                        <p class="card-text" style="font-size:0.95rem;"><?php echo e(\Illuminate\Support\Str::limit($rifa->descricao, 65)); ?></p>
                        <ul class="list-group list-group-flush mb-2">
                            <li class="list-group-item" style="font-size:0.92rem;"><b>Valor:</b> <span class="text-success">R$ <?php echo e(number_format($rifa->valor,2,',','.')); ?></span></li>
                            <li class="list-group-item" style="font-size:0.92rem;"><b>Sorteio:</b> <span class="text-warning"><?php echo e(\Carbon\Carbon::parse($rifa->data_sorteio)->format('d/m/Y H:i')); ?></span></li>
                        </ul>
                    </div>
                    <div class="card-footer text-center bg-transparent">
                        <a href="<?php echo e(route('public.rifas.show', $rifa)); ?>" class="btn btn-outline-light btn-sm me-2">Detalhes</a>
                        <a href="<?php echo e(route('rifa.show', $rifa->id)); ?>" class="btn btn-main btn-sm">Participar</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-info text-center">Nenhum sorteio cadastrado ainda.</div>
            </div>
        <?php endif; ?>
    </div>

    <h2 class="section-title text-center my-5" style="font-size:1.22rem;">Perguntas Frequentes (FAQ)</h2>
    <div class="accordion mb-5" id="faqAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="faq1">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faqContent1" aria-expanded="true">
                    Como participo de um sorteio?
                </button>
            </h2>
            <div id="faqContent1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                <div class="accordion-body" style="font-size:0.98rem;">
                    Basta escolher um sorteio, selecionar seus números e efetuar o pagamento pelo site. Você receberá a confirmação por WhatsApp!
                </div>
            </div>
        </div>
        <div class="accordion-item">
            <h2 class="accordion-header" id="faq2">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqContent2">
                    Quais formas de pagamento são aceitas?
                </button>
            </h2>
            <div id="faqContent2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body" style="font-size:0.98rem;">
                    Aceitamos Pix, boleto e cartão de crédito, tudo online, rápido e seguro.
                </div>
            </div>
        </div>
        <div class="accordion-item">
            <h2 class="accordion-header" id="faq3">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqContent3">
                    Como sei se ganhei?
                </button>
            </h2>
            <div id="faqContent3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body" style="font-size:0.98rem;">
                    O resultado é divulgado ao vivo no site e você também é notificado pelo WhatsApp cadastrado.
                </div>
            </div>
        </div>
        <div class="accordion-item">
            <h2 class="accordion-header" id="faq4">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqContent4">
                    É seguro participar?
                </button>
            </h2>
            <div id="faqContent4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body" style="font-size:0.98rem;">
                    Sim! Nosso sistema é transparente, protegido e todos os sorteios têm auditoria e divulgação pública.
                </div>
            </div>
        </div>
    </div>

    <div class="text-center my-5">
        <a href="<?php echo e(route('bicho.resultado')); ?>" class="btn btn-main btn-lg shadow">Ver Resultado do Jogo do Bicho</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/htdocs/Sites/rifas/resources/views/home.blade.php ENDPATH**/ ?>