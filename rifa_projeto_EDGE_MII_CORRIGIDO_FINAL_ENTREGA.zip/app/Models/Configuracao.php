
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Configuracao extends Model
{
    protected $fillable = ['chave', 'valor'];

    public static function get($chave, $default = null)
    {
        return static::where('chave', $chave)->value('valor') ?? $default;
    }

    public static function set($chave, $valor)
    {
        return static::updateOrCreate(['chave' => $chave], ['valor' => $valor]);
    }
}
