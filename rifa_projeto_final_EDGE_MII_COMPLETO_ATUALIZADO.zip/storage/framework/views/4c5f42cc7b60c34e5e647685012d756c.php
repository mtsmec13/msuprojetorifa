<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Nova Rifa</h2>
    <form action="<?php echo e(route('admin.rifas.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('admin.rifas.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <button class="btn btn-success">Salvar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/htdocs/Sites/rifas/resources/views/admin/rifas/create.blade.php ENDPATH**/ ?>