<div class="mb-3">
    <label>Título</label>
    <input type="text" name="titulo" class="form-control" value="<?php echo e(old('titulo', $rifa->titulo ?? '')); ?>" required>
</div>
<div class="mb-3">
    <label>Descrição</label>
    <textarea name="descricao" class="form-control" required><?php echo e(old('descricao', $rifa->descricao ?? '')); ?></textarea>
</div>
<div class="mb-3">
    <label>Valor</label>
    <input type="number" step="0.01" name="valor" class="form-control" value="<?php echo e(old('valor', $rifa->valor ?? '')); ?>" required>
</div>
<div class="mb-3">
    <label>Quantidade de Números</label>
    <input type="number" name="quantidade_numeros" class="form-control" value="<?php echo e(old('quantidade_numeros', $rifa->quantidade_numeros ?? '')); ?>" required>
</div>
<div class="mb-3">
    <label>Data do Sorteio</label>
    <input type="date" name="data_sorteio" class="form-control" value="<?php echo e(old('data_sorteio', isset($rifa) ? \Carbon\Carbon::parse($rifa->data_sorteio)->format('Y-m-d') : '')); ?>" required>
</div>
<div class="mb-3">
    <label>Tipo de Sorteio</label>
    <select name="tipo_sorteio" class="form-control">
        <option value="manual" <?php echo e(old('tipo_sorteio', $rifa->tipo_sorteio ?? '') == 'manual' ? 'selected' : ''); ?>>Manual</option>
        <option value="automatico" <?php echo e(old('tipo_sorteio', $rifa->tipo_sorteio ?? '') == 'automatico' ? 'selected' : ''); ?>>Automático</option>
    </select>
</div>
<div class="mb-3">
    <label>Prêmio 1º lugar</label>
    <input type="text" name="premio_1" class="form-control" value="<?php echo e(old('premio_1', $rifa->premio_1 ?? '')); ?>">
</div>
<div class="mb-3">
    <label>Prêmio 2º lugar</label>
    <input type="text" name="premio_2" class="form-control" value="<?php echo e(old('premio_2', $rifa->premio_2 ?? '')); ?>">
</div>
<div class="mb-3">
    <label>Prêmio 3º lugar</label>
    <input type="text" name="premio_3" class="form-control" value="<?php echo e(old('premio_3', $rifa->premio_3 ?? '')); ?>">
</div>
<div class="form-check mb-3">
    <input class="form-check-input" type="checkbox" name="mostrar_banner" id="mostrar_banner"
        <?php echo e(old('mostrar_banner', $rifa->mostrar_banner ?? false) ? 'checked' : ''); ?>>
    <label class="form-check-label" for="mostrar_banner">
        Exibir esta rifa no banner da home?
    </label>
</div>
<div class="mb-3">
    <label>Imagem (opcional)</label>
    <input type="file" name="imagem" class="form-control">
    <?php if(isset($rifa) && $rifa->imagem): ?>
        <img src="<?php echo e($rifa->imagem); ?>" style="max-width: 150px;" class="mt-2">
    <?php endif; ?>
</div>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($erro); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?><?php /**PATH /data/data/com.termux/files/home/htdocs/Sites/rifas/resources/views/admin/rifas/form.blade.php ENDPATH**/ ?>